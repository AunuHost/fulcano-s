import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "100"))

DEVS = list(map(int, os.getenv("DEVS", "8359234400").split()))

API_ID = int(os.getenv("API_ID", "29289753"))

API_HASH = os.getenv("API_HASH", "3f209b867db1920f5246bf523246fd74")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8279035116:AAEmengHUrAw9o0Qw0ERkRzFJlP5AG6JtOc")

OWNER_ID = int(os.getenv("OWNER_ID", "8359234400"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "").split()))

RMBG_API = os.getenv("RMBG_API", "MA2sUZ4HdAfBegL36HiG4BUG")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://AunuHost:AunuHost8080@cluster0.l2j3g7o.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-4809875074"))
