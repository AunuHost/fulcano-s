from PyroUbot import *

__MODULE__ = "limit"
__HELP__ = """
perintah : <code>{0}limit</code>
    mengecek status akun apakah terkena limit atau tidak
"""

